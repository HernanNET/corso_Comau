#!/usr/bin/env python
# coding: utf-8
'''
Esercizi in metafora - LIBRERIA

TASK 1

Manipolazione di files
Create un programma Python che legga da un file .txt (con valori separati da virgola) l'elenco dei libri presenti in libreria e per ogni genere differente sappia salvare la lista di libri appartenenti a quel genere.
'''

# leggi il file libri.txt
import csv
file_libri = open("libri.txt","r")  
reader = csv.reader(file_libri) # Restituisce un oggetto reader che itererà su righe nel file csv specificato.
# Ogni riga letta dal file csv viene restituita come un elenco di stringhe.
# lista di dizionari 

# importa i dati in formato lista, dove ogni riga e' un dizionario contenete le seguenti chiavi:
# titolo, autore, prezzo, genere

libreria = [] #database dei libri (inizialmente vuoto)
headers = [] #lista con le intestazioni dele colonne
for riga in reader: #leggo la prima riga per riempire la lista headers
    for label in riga:
        headers.append(label)
    break #mi fermo alla prima riga
for riga in reader: #ciclo su tutte le altre righe
    #libro = {'titolo' : riga[0], 'autore' : riga[1], 'prezzo' : riga[2], 'genere' : riga[3]}
    libro = {}
    for key, value in zip(headers, riga): #creo dizionario libro con chiave 'titolo', 'genere', etc. e valori corrispondenti per ogni riga
        libro[key] = value
    libreria.append(libro) #metto il libro nel database libreria

print(libreria) #stampa tutta libreria
print(libreria[5]) #stampa singola riga
print([libro['titolo'] for libro in libreria]) #stampa singola colonna
print(libreria[6]['prezzo']) #stampa una cella

# salva i libri divisi per genere

lib_horror = []
for libro in libreria:
    if libro['genere'] == 'Horror':
        lib_horror.append(libro)
    else:
        continue

'''
# old style loop with index
lib_horror = []
for i in range(10):
    if libreria[i]['genere'] == 'Horror':
        lib_horror.append(libreria[i])
'''

# horr_book

print('\n')
print(lib_horror)

# chiudi il riferimento al file

file_libri.close()

'''
TASK 2

Input da tastiera
Create un programma Python che legga da un file .txt l'elenco dei clienti possessori della tessera fedeltà e che chieda in input il loro nome e salvi come dato aggiuntivo il loro genere preferito (sempre da input). Al termine dell'operazione, visualizzare su schermo la lista dei clienti aggiornata.
'''

# leggi il file clienti.txt 
# NB nella prima colonna e' salvato il nome, nella seconda l'età e nella terza colonna i punti accumulati.

file_clienti = open("clienti.txt","r")  
reader = csv.DictReader(file_clienti) #costruzione DB clienti conmetodo DictReader
db_clienti = [] #DB vuoto
for cliente in reader:
    db_clienti.append(cliente) #aggiungo cliente a DB

#input da tastiera del nome cliente e del genere preferito

nome = input('come ti chiami?')

# aggiungi alla lista clienti il genere preferito del cliente appena memorizzato
found = False
fieldnames = db_clienti[0].keys() #label delle colonne del db clienti
for cliente in db_clienti: #itero sui clienti
    if cliente['nome'] == nome: #se trovo il cliente 
        cliente['genere'] = input('che genere preferisci?') #gli chiedo il genere preferito e aggiorno DB
        found = True #flag che l'ho trovato
        cliente_in_negozio = cliente #salvo i suoi dati in una var per dopo
        break #esco dal ciclo

# se non l'ho trovato aggiungo nuovo cliente al db.
if not found:
    eta = int(input('Quanti anni hai?'))
    punti = 10
    genere = input('che genere preferisci?')
    values = [nome, eta, punti, genere]
    cliente = {}
    for key, value in zip(fieldnames, values):
        cliente[key] = value
    db_clienti.append(cliente)
    cliente_in_negozio = cliente #salvo i suoi dati in una var per dopo

    
# mostra la lista aggiornata

print(db_clienti)

# chiudi i riferimenti al file

file_clienti.close()

#scrivo su file clienti aggiornato

file_clienti_update = open('clienti_update.csv', 'w', newline='')
writer = csv.DictWriter(file_clienti_update, fieldnames=fieldnames)
writer.writeheader()
for cliente in db_clienti:
    writer.writerow(cliente)

file_clienti_update.close()

'''
TASK 3

Le funzioni
Create un programma Python che calcoli i seguenti sconti:
- Sconto del 30% su qualsiasi libro per i clienti con età superiore a 60 anni, minore di 20 e amanti del Mystery;
- Sconto del 15% ai clienti con età  compresa tra i 30 e i 50 o con punti fedeltà  maggiore di 30;
- Sconto del 50% per tutti gli amanti del Fantasy.

Chieda all'utente quale libro ha scelto di acquistare e calcoli il prezzo finale con lo sconto corrispondente

'''


# crea la funzione che calcola gli sconti

def sconto(eta, punti, genere):
    if genere == 'Fantasy':
        return 0.5
    elif (eta <=20 or eta >= 60) and genere == 'Mystery':
        return 0.3
    elif 30 <= eta <= 50 and punti >= 30:
        return 0.15
    else:
        return 0.0

#prova funzione   
#print(sconto(20, 40, 'Mystery')) #test funzione


# chiedi all'utente quale libro ha scelto di acquistare

libro_cliente = input('Che libro desideri?')


# scorrendo la lista di libri estrai il prezzo del libro scelto

found = False
for libro in libreria:
    if libro['titolo'] == libro_cliente:
        prezzo_libro = float(libro['prezzo'])
        found = True
        break
    else:
        continue

if not found:
    print('Non ho questo libro, scegline un altro!')


# estrai l'eta del cliente, il suo genere preferito e i punti accumulati 

eta = int(cliente_in_negozio['eta'])
punti = int(cliente_in_negozio['punti'])
genere = cliente_in_negozio['genere']


#calcola sconto usando la funzione creata in precedenza

scontistica = sconto(eta, punti, genere)


# calcola il prezzo finale e stampalo

print(prezzo_libro * (1 - scontistica))