#!/usr/bin/env python
# coding: utf-8
'''
Esercizi in metafora - CONTO CORRENTE

TASK 1

Create una classe Account che sappia inizializzare il nome del cliente e i fondi iniziali. Depositare nuovi fondi, prelevare i fondi e visualizzare il saldo. 

NB: I prelievi non possano superare il saldo disponibile!

'''

# Crea la classe Account
class Account:
    pass




'''
TASK 2

Create 3 classi derivate che ereditano le funzionalità della classe Account ed estendono le loro funzionalità come segue: tutte e 3 devono poter visualizzare nelle info il loro tipo di account e in aggiunta per ogni sotto classe

- Premium - Emettere bonifici nazionali ed esteri gratuiti, depositare costo 0
- Medium - Emettere bonifici nazionali gratuiti e internazionali al costo di 1 euro, e depositare al costo di 1 euro
- Standard - Funzionalità standard, solo bonifico nazionale, e depositare al costo di 2 euro

'''


# Crea la classe Premium che eriditi dalla classe Account e possa emettere bonifici nazionali ed esteri gratuiti, e depositare fondi a costo 0

class Premium(Account):
    pass










# Crea la classe Medium che eriditi dalla classe Account e possa emettere bonifici nazionali gratuiti e esteri al costo di 1 euro, 
# e depositare fondi a costo di 1 euro

class Medium(Account):
    pass




# Crea la classe Standard che erediti dalla classe Account, possa fare solo bonifici nazionali ed il costo del deposito sia di 2 euro

class Standard(Account):
    pass


