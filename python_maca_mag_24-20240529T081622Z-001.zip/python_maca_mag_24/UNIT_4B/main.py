from Conto_Corrente import *

# Prova le funzionalità  della classe Account
# 1. crea un'istanza
# 2. controlla i fondi
# 3. Aggiungi e preleva fondi (prova a prelevare un importo superiore al saldo)


# Prova la classe Premium
# 1. Crea due istanze ed emetti bonifico

# Prova la classe Medium
# 1. Crea un'istanza
# 2. Emetti bonifico (nazionale e internazionale)
# 3. Deposita fondi

# Prova la classe Standard
# 1. Crea un'istanza
# 2. Emetti bonifico nazionale e provane uno internazionale
# 3. Deposita fondi